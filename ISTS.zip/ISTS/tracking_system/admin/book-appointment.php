<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
if(isset($_POST['submit']))
{
$tech1=$_POST['technician1'];
$tech2=$_POST['technician2'];
$value = $_POST["make"];
$text = $_POST["make_text"];
$userid=$_SESSION['id'];
$appdate=$_POST['appdate']; 

	$query=mysql_query("insert into appointment(instrument_id,instrument_name,created_by,assigndate,technician1,technician2) values('$value','$text','$userid','$appdate','$tech1','$tech2')");
	if($query)
	{
		echo "<script>alert('Your appointment successfully booked');</script>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>admin  | Book Appointment</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
		<link href="bootstrap-chosen.css" rel="stylesheet">
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxedn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  
  <script>
	$(document).ready(function () {
    var date = new Date();
    var currentMonth = date.getMonth();
    var currentDate = date.getDate();
    var currentYear = date.getFullYear();

    $('#datepicker').datepicker({
        minDate: new Date(currentYear, currentMonth, currentDate),
        dateFormat: 'yyyy-mm-dd'
    });
});
  </script>





	</head>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
			
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
									<div class="span012">
							<ul class="nav nav-tabs navbar-inverse">
							 <li><a href="dashboard.php"><h4>HOME</h4></a></li>
							 <li><a href="media/template.xlsx"><h4>DOWNLOAD</h4></a></li>
							 <li><a href="upload.php"><h4>UPLOAD</h4></a></li>
							</ul>
							</div>
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">admin | Book Assignment</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>admin</span>
									</li>
									<li class="active">
										<span>Book Assignment</span>
									</li>
								</ol>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">
									
									<div class="row margin-top-30">
										<div class="col-lg-8 col-md-12">
											<div class="panel panel-white">
												<div class="panel-heading">
													<h5 class="panel-title">Book Appointment</h5>
												</div>
												<div class="panel-body">
								<p style="color:red;"><?php echo htmlentities($_SESSION['msg1']);?>
								<?php echo htmlentities($_SESSION['msg1']="");?></p>	
													<form role="form" name="book" method="post" >
														


                                                                    <div class="form-group">
															<label for="technicianspecialization">
																Instrument name
															</label>
							<select name="make" class="chosen-select" onchange="setTextField(this)" required="required">
																<option value="">select instrument</option>
                                                            <?php $ret=mysql_query("select * from technicianspecilization");
                                                                                while($row=mysql_fetch_array($ret))
                                                                {
                                                               ?>
																<option value="<?php echo htmlentities($row['id']);?>">
																	<?php echo htmlentities($row['specilization']);?> 
																</option>
																<?php } ?>
																
															</select>
															
															<input id="make_text" type = "hidden" name = "make_text" value = "" />
															<script type="text/javascript">
															function setTextField(ddl) {
															document.getElementById('make_text').value = ddl.options[ddl.selectedIndex].text;
															}
															</script>
														</div>
<div class="form-group">
									<label for="fess">
																Technician 1
															</label>
					<select name="technician1" class="chosen-select"  required="required">
																<option value="">Select technician 1</option>
                                                            <?php $ret=mysql_query("select * from users where category='admin' or category='technician'");
                                                                                while($row=mysql_fetch_array($ret))
                                                                {
                                                               ?>
																<option value="<?php echo htmlentities($row['id']);?>">
																	<?php echo htmlentities($row['name']);?>
																</option>
																<?php } ?>
																
															</select>
														</div>
														
<div class="form-group">
									<label for="fess">
																Technician 2
															</label>
					<select name="technician2" class="chosen-select"  required="required">
																<option value="">Select technician 2</option>
                                                            <?php $ret=mysql_query("select * from users where category='admin' or category='technician'");
                                                                                while($row=mysql_fetch_array($ret))
                                                                {
                                                               ?>
																<option value="<?php echo htmlentities($row['id']);?>">
																	<?php echo htmlentities($row['name']);?>
																</option>
																<?php } ?>
																
															</select>
														</div>


														
														
<div class="form-group">
															<label for="AppointmentDate">
															     Date
															</label>
											
									         <input class="form-control datepicker" data-provide="datepicker" data-date-format="yyyy-mm-dd" name="appdate" id="datepicker" placeholder="yyyy/mm/dd" type="text" required="required" autocomplete="off"> 
														</div>
														
                                                          <div class="form-group">
																											
														
														<button type="submit" name="submit" class="btn btn-o btn-primary">
															Submit
														</button>
													</form>
												</div>
											</div>
										</div>
											
											</div>
										</div>
									
									</div>
								</div>
							
						<!-- end: BASIC EXAMPLE -->
			
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	
			
			<!-- end: SETTINGS -->
			</div>
			</div>
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->


<!--  this is from website ******************************************************-->
		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="chosen.jquery.js"></script>
	<script >
	$('.chosen-select').chosen();
	</script>
	</body>
</html>
