<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
if(isset($_POST['clear']))
{
	$del=mysql_query("TRUNCATE TABLE temp_table");
	if($del)
	{
		echo "<script>alert('data cleared');</script>";
	}
}

if(isset($_POST['upload']))
{
	$userid=$_SESSION['id'];
	$temp=mysql_query("select * from temp_table");
	while($row=mysql_fetch_array($temp))
	{
		$cus1=$row['custodian1'];
		$em1=$row['email1'];
		$cus2=$row['custodian2'];
		$em2=$row['email2'];
		$user=mysql_query("select * from users where name='$cus1' and email='$em1'");
		$num=mysql_fetch_array($user);
		if($num>0)
		{
			$t1=$row['custodian1'];
		}
		else
		{
				$c1=$row['custodian1'];
				$p1=$row['mob1'];
				$e1=$row['email1'];
				$newInst=mysql_query("insert into users(name,contactno,email,category) values('$c1','$p1','$e1','technician')");
				if($newInst)
				{
					$t1=$row['custodian1'];
				}
		}
		
		$user1=mysql_query("select * from users where name='$cus2' and email='$em2'");
		$num1=mysql_fetch_array($user1);
		if($num1>0)
		{
			$t2=$row['custodian2'];
		}
		else
		{
				$c2=$row['custodian2'];
				$p2=$row['mob2'];
				$e2=$row['email2'];
				$newInst=mysql_query("insert into users(name,contactno,email,category) values('$c2','$p2','$e2','technician')");
				if($newInst)
				{
					$t2=$row['custodian2'];
				}
		}
		
		$inst=mysql_query("select * from technicianspecilization");
		while($row1=mysql_fetch_array($inst))
		{
			if(($row1['id'] == $row['Inst_id']) && ($row1['specilization'] == $row['Inst_name']) )
			{
				$instrumentid=$row['Inst_id'];
				$instrumentname=$row['Inst_name'];
			}
			else
			{
				$inst_id=$row['Inst_id'];
				$inst_name=$row['Inst_name'];
				$newInst=mysql_query("insert into technicianspecilization(id,specilization) values('$inst_id','$inst_name')");
				if($newInst)
				{
					$instrumentid=$row['Inst_id'];
					$instrumentname=$row['Inst_name'];
				}
			}	
		}
		
		//$cust2=$row['custodian2'];
		$n1=mysql_query("select * from users where name='$t1'");
		while($row3=mysql_fetch_array($n1))
		{
			$name1=$row3['id'];
		}
		$n2=mysql_query("select * from users where name='$t2'");
		while($row4=mysql_fetch_array($n2))
		{
			$name2=$row4['id'];
		}
		$assign=$row['calibration_duedate'];
		$result=mysql_query("insert into appointment(instrument_id,instrument_name,created_by,assigndate,technician1,technician2) values('$instrumentid','$instrumentname','$userid','$assign','$name1','$name2')");

	}
	$del=mysql_query("TRUNCATE TABLE temp_table");
	if($del)
	{
		echo "<script>alert('Your upload successfully booked');</script>";
	}
	
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>admin | Assignment History</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
	</head>
	<body>
	
		<div id="app">		

		
				

					<?php include('include/header.php');?>
					<br>
					<br>
					<br>
					
				<!-- end: TOP NAVBAR -->
				<div class="span012" id="fixedbutton ">
							<ul class="nav nav-tabs navbar-inverse">
							 <li><a href="dashboard.php"><h4>HOME</h4></a></li>
							 <li><a href="media/template.xlsx"><h4>DOWNLOAD</h4></a></li>
							 <li class="active"><a href="upload.php"><h4>UPLOAD</h4></a></li>
							</ul>
							</div>
				
				
						<!-- start: PAGE TITLE -->
						
				<center>	<p><h1> UPLOAD DATA </h1></p> </center>
					
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						<form method='post' name='clear' action='upload.php'>
		</div>
		<div style='float: left; width: 130px'>	
			<center><button class='btn btn-primary' type='submit' name='clear'> clear data</button></center></div><h5>clear data before uploading</h5>
		</form>
		<br>
		<br>
						
						<?php
require_once 'Classes/PHPExcel.php';

//we can combine this with file upload
$id=array();
	echo "
	   
		<div style='width:1200px;'>		
				<div style='float: left; width: 130px'>
		<form method='post' enctype='multipart/form-data' action='upload.php'>
		 <input  type='file' name='excel'>
		 <br>
		 <button class='btn btn-primary' type='submit'>upload</button>
		</form>
		<br>
		<form method='post' name='upload' action='upload.php'>
		</div>
		<div style='float: right; width: 130px'>	
			<center><button class='btn btn-primary' type='submit' name='upload'> save and update</button></center></div>
		</form>
		<br>
		<br>
		<br><center>
		<h5 style='color:#0845dd;' type='textarea'><u><b> MAKE SURE FIRST CELL 'A' is not empty </b></u></h5></center>
	";
	
echo "<table border=1 style='width:1300px'>";

		
//load excel file using phpExcel's IOFactory
$excel = PHPExcel_IOFactory::load($_FILES['excel']['tmp_name']);

//set active sheet to first sheet
$excel->setActiveSheetIndex(0);



//first row data series 
$i = 1;
//loop until the end of data series 
while( $excel->getActiveSheet()->getCell('A'.$i)->getValue() !=""){
	//get cells value
	$S_no = $excel->getActiveSheet()->getCell('A'.$i)->getValue();
	$calibration_dueDate = $excel->getActiveSheet()->getCell('B'.$i)->getValue();
	$Instrument_Name = $excel->getActiveSheet()->getCell('C'.$i)->getValue();
	$InstrumentID = $excel->getActiveSheet()->getCell('D'.$i)->getValue();
	$Custodian1 = $excel->getActiveSheet()->getCell('E'.$i)->getValue();
	$MobileNO1 = $excel->getActiveSheet()->getCell('F'.$i)->getValue();
	$Emailid1 = $excel->getActiveSheet()->getCell('G'.$i)->getValue();
	$Custodian2 = $excel->getActiveSheet()->getCell('H'.$i)->getValue();
	$MobileNO2 = $excel->getActiveSheet()->getCell('I'.$i)->getValue();
	$Emailid2 = $excel->getActiveSheet()->getCell('J'.$i)->getValue();
	
	//echo
	if($S_no=="" || $calibration_dueDate=="" || $Instrument_Name=="" || $InstrumentID=="" || $Custodian1=="" || $MobileNO1=="" || $Emailid1=="" || $Custodian2=="" || $MobileNO2=="" || $Emailid2=="" ||$S_no=="S.No." )
	{	echo"
	     <tr>
		      <td style='background-color:#ef0420;'>".$S_no."</td>
			  <td style='background-color:#ef0420;'>".$calibration_dueDate."</td>
			  <td style='background-color:#ef0420;'>".$Instrument_Name."</td>
			  <td style='background-color:#ef0420;'>".$InstrumentID."</td> 
			  
			<td style='background-color:#ef0420;'>".$Custodian1."</td>
			  <td style='background-color:#ef0420;'>".$MobileNO1."</td>
			  <td style='background-color:#ef0420;'>".$Emailid1."</td>
			  <td style='background-color:#ef0420;'>".$Custodian2."</td>
			  <td style='background-color:#ef0420;'>".$MobileNO2."</td>
			  <td style='background-color:#ef0420;'>".$Emailid2."</td>
		</tr>
		";
	}
	else
	{
		$connect = mysqli_connect('localhost', 'root', '', 'ists');
		$query="insert into temp_table(sl_no,calibration_duedate,Inst_name,Inst_id,custodian1,mob1,email1,custodian2,mob2,email2)
		             values('$S_no','$calibration_dueDate','$Instrument_Name','$InstrumentID','$Custodian1','$MobileNO1','$Emailid1','$Custodian2','$MobileNO2','$Emailid2')";
		mysqli_query($connect,$query);
		
		echo"
	     <tr>
		 
		      <td>".$S_no."</td>
			  <td>".$calibration_dueDate."</td>
			  <td>".$Instrument_Name."</td>
			  <td>".$InstrumentID."</td> 
			  
			<td>".$Custodian1."</td>
			  <td>".$MobileNO1."</td>
			  <td>".$Emailid1."</td>
			  <td>".$Custodian2."</td>
			  <td>".$MobileNO2."</td>
			  <td>".$Emailid2."</td>
		</tr>
		";
		}
		$i ++;
}

echo"</table>";
?>
  
							</div>
								</div>
								
						
						
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
